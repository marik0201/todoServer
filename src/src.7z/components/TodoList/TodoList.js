import React, { Component } from "react";
import "./TodoList.scss"

class TodoList extends React.Component {
    render() {
      return (
        <>
          {this.props.items.map(item => (
            <div className="message" key={item.id}>{item.text}</div>
          ))}
        </>
      );
    }
  }

export default TodoList;